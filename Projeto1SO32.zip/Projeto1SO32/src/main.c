#include "include/main.h"


int main(int argc, char *argv[]) {
//init data structures
struct main_data* data = create_dynamic_memory(sizeof(struct main_data));
struct comm_buffers* buffers = create_dynamic_memory(sizeof(struct comm_buffers));
buffers->main_client = create_dynamic_memory(sizeof(struct rnd_access_buffer));
buffers->client_interm = create_dynamic_memory(sizeof(struct circular_buffer));
buffers->interm_enterp = create_dynamic_memory(sizeof(struct rnd_access_buffer));
//execute main code
main_args(argc, argv, data);
create_dynamic_memory_buffers(data);
create_shared_memory_buffers(data, buffers);
launch_processes(buffers, data);
user_interaction(buffers, data);
//release memory before terminating
destroy_dynamic_memory(data);
destroy_dynamic_memory(buffers->main_client);
destroy_dynamic_memory(buffers->client_interm);
destroy_dynamic_memory(buffers->interm_enterp);
destroy_dynamic_memory(buffers);
}


void main_args(int argc, char* argv[], struct main_data* data){
    
}


void create_dynamic_memory_buffers(struct main_data* data){

}


void create_shared_memory_buffers(struct main_data* data, struct comm_buffers* buffers){

}


void launch_processes(struct comm_buffers* buffers, struct main_data* data){

}


void user_interaction(struct comm_buffers* buffers, struct main_data* data){

}


void create_request(int* op_counter, struct comm_buffers* buffers, struct main_data* data){

}


void read_status(struct main_data* data){

}


void stop_execution(struct main_data* data, struct comm_buffers* buffers){

}


void wait_processes(struct main_data* data){

}


void write_statistics(struct main_data* data){

}


void destroy_memory_buffers(struct main_data* data, struct comm_buffers* buffers){

}
